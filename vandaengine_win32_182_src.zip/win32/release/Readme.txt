Vanda Engine 1.8.2
Copyright (C) 2022 Ehsan Kamrani
www.vanda3d.org
www.facebook.com/vandaengine
I removed Twitter account as it violates freedom of expression
www.youtube.com/vandaengine1
Please report the bugs to opentechno@hotmail.com
For more information about this application, please refer to the User's Manual