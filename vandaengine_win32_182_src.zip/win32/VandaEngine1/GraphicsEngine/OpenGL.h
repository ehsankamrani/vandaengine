//Copyright (C) 2022 Ehsan Kamrani 
//This file is licensed and distributed under MIT license

#pragma once

#include <GL\glew.h>
#include <GL\wglew.h>
#include <GL\glaux.h>
#include <GL\glut.h>
#pragma comment( lib, "glew32.lib" )
#pragma comment( lib, "opengl32.lib" )
#pragma comment( lib, "glu32.lib" )
#pragma comment( lib, "glaux.lib" )
#pragma comment( lib, "glut32.lib" )