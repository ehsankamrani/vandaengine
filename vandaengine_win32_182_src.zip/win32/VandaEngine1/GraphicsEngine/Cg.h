//Original Work: Copyright 2006 Sony Computer Entertainment Inc.
//Modified Work: Copyright (C) 2022 Ehsan Kamrani 
//This file is licensed and distributed under MIT license

#pragma once 

#include <cg\cg.h>	
#include <cg\cggl.h>

#define USE_CG

#pragma comment( lib, "cg.lib" )
#pragma comment( lib, "cggl.lib" )

 

