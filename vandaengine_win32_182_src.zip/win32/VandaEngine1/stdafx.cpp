//Copyright (C) 2022 Ehsan Kamrani 
//This file is licensed and distributed under MIT license

// stdafx.cpp : source file that includes just the standard includes
// VandaEngine.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
CUInt g_nameIndex = 1;  
CUInt g_nodeIndex = 1;
CInt g_selectedName = -1; //No valid name at the beginning
CInt g_numVerts = 0; // number of scene vertexes
