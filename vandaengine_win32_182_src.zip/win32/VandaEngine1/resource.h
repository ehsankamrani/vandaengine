//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VandaEngine1.rc
//
#define IDC_MYICON                      2
#define IDD_VANDAENGINE_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDC_VANDAENGINE                 109
#define IDR_MAINFRAME                   128
#define IDD_INIT_DIALOG                 129
#define IDB_LOGO                        130
#define IDI_VANDAENGINE                 133
#define IDI_SMALL                       134
#define IDC_DVSYNC                      1000
#define IDC_MSAMPLE_NO                  1001
#define IDC_MSAMPLE_2                   1002
#define IDC_MSAMPLE_4                   1003
#define IDC_MSAMPLE_8                   1004
#define IDC_MSAMPLE_16                  1005
#define IDC_FBO                         1006
#define IDC_ISOTROP_NO                  1007
#define IDC_ISOTROP_2                   1008
#define IDC_ISOTROP_4                   1009
#define IDC_ISOTROP_8                   1010
#define IDC_ISOTROP_16                  1011
#define IDC_VBO                         1012
#define IDC_RES_CURRENT                 1013
#define IDC_RES_800                     1014
#define IDC_RES_1024                    1015
#define IDC_RES_1280                    1016
#define IDC_RES_1920                    1017
#define IDC_RES_2560                    1018
#define IDC_RES_3840                    1019
#define IDC_RES_7680                    1020
#define IDC_STATIC_LOGO                 1021
#define IDC_WATER_REFLECTION            1022
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
